/*
** EPITECH PROJECT, 2019
** builtin_executor.c
** File description:
** executor of builtin commande
*/

#include "ftsh.h"

void my_setenv2(shell_t *shell, tree_t *tree)
{
    if (tree->fd[0] != 0)
        dup2(tree->fd[0], 0);
    if (tree->fd[1] != 1)
        dup2(tree->fd[1], 1);
    if (tree->fd[2] != 0)
        close(tree->fd[2]);
    if (tree->fd[3] != 1)
        close(tree->fd[3]);
    my_setenv_list(shell, tree->cmd);
    exit(0);
}

void my_setenv(shell_t *shell, tree_t *tree)
{
    int pid = -1;

    if (tree->fd[0] == 0 && tree->fd[1] == 1)
        return (my_setenv_list(shell, tree->cmd));
    pid = fork();
    if (pid == -1) {
        set_err(shell, 3);
        return;
    }
    if (!pid) {
        return (my_setenv2(shell, tree));
    } else
        exec_cmd_father(shell, pid, tree->fd);
    return;
}

void my_where2(shell_t *shell, tree_t *tree)
{
    if (tree->fd[0] != 0)
        dup2(tree->fd[0], 0);
    if (tree->fd[1] != 1)
        dup2(tree->fd[1], 1);
    if (tree->fd[2] != 0)
        close(tree->fd[2]);
    if (tree->fd[3] != 1)
        close(tree->fd[3]);
    where(shell, *tree->cmd);
    exit(0);
}

void my_where(shell_t *shell, tree_t *tree)
{
    int pid = -1;

    if (tree->fd[0] == 0 && tree->fd[1] == 1)
        return (where(shell, tree->cmd[1]));
    pid = fork();
    if (pid == -1) {
        set_err(shell, 3);
        return;
    }
    if (!pid) {
        return (my_where2(shell, tree));
    } else
        exec_cmd_father(shell, pid, tree->fd);
    return;
}
