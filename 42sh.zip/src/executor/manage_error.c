/*
** EPITECH PROJECT, 2019
** manage_error.c
** File description:
** manage error
*/

#include "ftsh.h"

void manage_error(int pid)
{
    if (WIFSIGNALED(pid)) {
        if (WTERMSIG(pid) == SIGSEGV)
            fprintf(stderr, "Segmentation fault");
        if (WTERMSIG(pid) == SIGFPE)
            fprintf(stderr, "Floating exception");
        if (WTERMSIG(pid) == SIGABRT)
            fprintf(stderr, "Abort");
        if (WCOREDUMP(pid))
            fprintf(stderr, " (core dumped)");
        fprintf(stderr, "\n");
    }
}

int bin_compatible(char *file)
{
    int fd;
    int r;
    static char buff[5];

    if (!file || access(file, F_OK) != 0)
        return (-1);
    fd = open(file, O_RDONLY);
    if (fd < 0)
        return (-1);
    memset(buff, 0, sizeof(buff));
    r = read(fd, buff, sizeof(buff));
    if (r < 4)
        return (-1);
    buff[4] = '\0';
    return ((strcmp(buff + 1, "ELF") == 0) ? 0 : -1);
}
