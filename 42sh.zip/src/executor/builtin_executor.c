/*
** EPITECH PROJECT, 2019
** builtin_executor.c
** File description:
** executor of builtin commande
*/

#include "ftsh.h"

void my_exit(shell_t *shell, UNUSED tree_t *tree)
{
    destroy_struct(shell);
}

void my_env2(shell_t *shell, tree_t *tree)
{
    if (tree->fd[0] != 0)
        dup2(tree->fd[0], 0);
    if (tree->fd[1] != 1)
        dup2(tree->fd[1], 1);
    if (tree->fd[2] != 0)
        close(tree->fd[2]);
    if (tree->fd[3] != 1)
        close(tree->fd[3]);
    my_env_list(shell, tree->cmd);
    exit(0);
}

void my_env(shell_t *shell, tree_t *tree)
{
    int pid = -1;

    if (tree->fd[0] == 0 && tree->fd[1] == 1)
        return (my_env_list(shell, tree->cmd));
    pid = fork();
    if (pid == -1) {
        set_err(shell, 3);
        return;
    }
    if (!pid) {
        return (my_env2(shell, tree));
    } else
        exec_cmd_father(shell, pid, tree->fd);
    return;
}
