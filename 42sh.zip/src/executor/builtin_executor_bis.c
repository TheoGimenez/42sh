/*
** EPITECH PROJECT, 2019
** builtin_executor.c
** File description:
** executor of builtin commande
*/

#include "ftsh.h"

void my_alias(shell_t *shell, tree_t *tree)
{
    if (!tree->cmd[1])
        return;
    my_add_alias(shell, tree->cmd[1], tree->cmd + 2);
}

void my_unalias(shell_t *shell, tree_t *tree)
{
    my_remove_alias(shell, tree->cmd[1]);
}

void my_cd(shell_t *shell, tree_t *tree)
{
    classic_cd(tree->cmd, shell);
}

void my_unsetenv(shell_t *shell, tree_t *tree)
{
    my_unsetenv_list(shell, tree->cmd);
}
