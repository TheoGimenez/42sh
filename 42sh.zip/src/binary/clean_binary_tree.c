/*
** EPITECH PROJECT, 2019
** make_binary_tree.c
** File description:
** create binary_tree
*/

#include "ftsh.h"

void clean_binary_tree(tree_t *tree)
{
    if (!tree)
        return;
    if (tree->left)
        clean_binary_tree(tree->left);
    if (tree->right)
        clean_binary_tree(tree->right);
    if (tree->cmd) {
        for (int i = 0; tree->cmd[i]; ++i)
            free(tree->cmd[i]);
        free(tree->cmd);
    }
    free(tree);
}
