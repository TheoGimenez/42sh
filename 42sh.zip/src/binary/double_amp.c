/*
** EPITECH PROJECT, 2019
** double_amp.c
** File description:
** manage double amperator
*/

#include "ftsh.h"

void double_amp(shell_t *shell, tree_t *tree)
{
    if (tree->left && !tree->right)
        return (set_err(shell, 1));
    if (tree->left)
        browse_binary_tree(shell, tree->left);
    if (shell->error == -1)
        return;
    browse_binary_tree(shell, tree->right);
}
