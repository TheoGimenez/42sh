/*
** EPITECH PROJECT, 2019
** browse_binary_tree.c
** File description:
** browse in binary_tree
*/

#include "ftsh.h"

void browse_check_separator(shell_t *shell, tree_t *tree)
{
    static const char *sep[] = {"||", "&&", "<<", ">>", "<", ">", "|"};
    static void (*sep_fct[])(shell_t *, tree_t *) = {double_pipe, double_amp, \
    redir_double_left, redir_double_right, redir_simple_left, \
    redir_simple_right, pipe_manager};
    static int array_size = sizeof(sep) / sizeof(void *);

    for (int i = 0; i != array_size; ++i) {
        if (!strcmp(sep[i], tree->parce)) {
            sep_fct[i](shell, tree);
            return;
        }
    }
}

void browse_binary_tree(shell_t *shell, tree_t *tree)
{
    if (!tree)
        return;
    tree->fd[0] = (tree->fd[0] == -1 ? 0 : tree->fd[0]);
    tree->fd[1] = (tree->fd[1] == -1 ? 1 : tree->fd[1]);
    if (tree->cmd) {
        cmd_manager(shell, tree);
        return;
    }
    if (tree->parce && !strcmp(tree->parce, ";")) {
        browse_binary_tree(shell, tree->left);
        shell->error = 0;
        return (browse_binary_tree(shell, tree->right));
    }
    if (tree->parce)
        return (browse_check_separator(shell, tree));
}
