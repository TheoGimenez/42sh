/*
** EPITECH PROJECT, 2019
** redir_simple_left.c
** File description:
** manage left simple redirection
*/

#include "ftsh.h"

void redir_simple_left(shell_t *shell, tree_t *tree)
{
    int fd = -1;

    if (!tree->right)
        return (set_err(shell, 4));
    if (!tree->left)
        return (set_err(shell, 1));
    fd = open(*tree->right->cmd, O_RDONLY);
    if (fd == -1) {
        if (errno == EACCES)
            fprintf(stderr, "%s: Permission denied.\n", *tree->right->cmd);
        if (errno == ENOENT)
            fprintf(stderr, "%s: No such file or directory.\n", \
            *tree->right->cmd);
        return (set_err(shell, -1));
    }
    memcpy(tree->left->fd, (int []) {fd, tree->fd[1], tree->fd[0], 1}, \
    sizeof(int) * 4);
    browse_binary_tree(shell, tree->left);
}
