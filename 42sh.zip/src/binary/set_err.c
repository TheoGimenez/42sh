/*
** EPITECH PROJECT, 2019
** set_err.c
** File description:
** set err var
*/

#include "ftsh.h"

void set_err(shell_t *shell, int err_code)
{
    shell->error = -1;
    if (err_code == 1)
        fprintf(stderr, "Invalid null command.\n");
    if (err_code == 2)
        fprintf(stderr, "Unexpeted error pipe()\n");
    if (err_code == 3)
        fprintf(stderr, "Unexpeted error fork()\n");
    if (err_code == 4)
        fprintf(stderr, "Missing name for redirect.\n");
    if (err_code == 5)
        fprintf(stderr, "Ambiguous output redirect.\n");
}
