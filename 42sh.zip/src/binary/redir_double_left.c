/*
** EPITECH PROJECT, 2019
** redir_double_left.c
** File description:
** manage left double redirection
*/

#include "ftsh.h"

void redir_double_left_read(int p_fd[2], char const *cmp)
{
    char *entry = NULL;
    int gl = -1;

    for (size_t n = 0; my_strcmp(cmp, entry); n = 0) {
        printf("? ");
        if (entry) {
            free(entry);
            entry = NULL;
        }
        gl = getline(&entry, &n, stdin);
        if (entry)
            entry[gl - 1] = entry[gl - 1] == 10 ? 0 : entry[gl - 1];
        if (gl == -1 || !my_strcmp(cmp, entry))
            break;
        write(p_fd[1], entry, n);
        write(p_fd[1], "\n", 1);
    }
    if (entry)
        free(entry);
}

void redir_double_left_fork(shell_t *shell, tree_t *tree, int p_fd[2])
{
    int pid = fork();
    int sig = -1;

    if (pid == -1)
        return (set_err(shell, 2));
    if (pid) {
        close(p_fd[0]);
        redir_double_left_read(p_fd, *tree->right->cmd);
        close(p_fd[1]);
        waitpid(pid, &sig, 0);
        if (sig_catch(sig) || sig)
            return (set_err(shell, -1));
    } else {
        browse_binary_tree(shell, tree->left);
        exit(shell->error ? 512 : 0);
    }
}

void redir_double_left(shell_t *shell, tree_t *tree)
{
    int p_fd[2] = {0, 0};

    if (!tree->right || tree->right->parce)
        return (set_err(shell, 4));
    if (!tree->left)
        return (set_err(shell, 1));
    if (pipe(p_fd) == -1)
        return (set_err(shell, 2));
    memcpy(tree->left->fd, \
    (int []) {p_fd[0], tree->fd[1], tree->fd[0], p_fd[1]}, sizeof(int) * 4);
    redir_double_left_fork(shell, tree, p_fd);
}
