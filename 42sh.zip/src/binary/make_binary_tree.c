/*
** EPITECH PROJECT, 2019
** make_binary_tree.c
** File description:
** create binary_tree
*/

#include "ftsh.h"

tree_t *create_leaf(char const *parce, char **cmd)
{
    tree_t *new = calloc(1, sizeof(tree_t));

    if (!new)
        return (NULL);
    new->fd[0] = -1;
    new->fd[1] = -1;
    new->parce = parce;
    new->cmd = cmd;
    return (new);
}

char **parse(char const *cmd, char const *sep, int const s_len, int const cmd_l)
{
    char **ret = NULL;
    int i = cmd_l - 1;

    for (; i > -1 && strncmp(cmd + i, sep, s_len); --i);
    i = i < 0 ? 0 : i;
    if (strncmp(cmd + i, sep, s_len) || !(ret = malloc(sizeof(char *) * 2)))
        return (NULL);
    if (!(ret[0] = calloc(i + 1, sizeof(char)))) {
        free(ret);
        return (NULL);
    }
    if (!(ret[1] = calloc(cmd_l - i + 1, sizeof(char)))) {
        free(ret[0]);
        free(ret);
        return (NULL);
    }
    strncpy(ret[0], cmd, i);
    strncpy(ret[1], cmd + i + s_len, cmd_l - i - s_len);
    return (ret);
}

tree_t *make_binary_tree(char const *cmd_line, int sep_index)
{
    static const char *sep[] = {";", "||", "&&", "<<", ">>", "<", ">", "|"};
    tree_t *node = NULL;
    char **tmp = NULL;

    if (sep_index < 8 && (tmp = parse(cmd_line, sep[sep_index], \
    strlen(sep[sep_index]), strlen(cmd_line)))) {
        node = create_leaf(sep[sep_index], NULL);
        node->right = make_binary_tree(tmp[1], sep_index);
        node->left = make_binary_tree(tmp[0], sep_index);
        free(tmp[0]);
        free(tmp[1]);
        free(tmp);
    } else if (sep_index < 8)
        node = make_binary_tree(cmd_line, sep_index + 1);
    else
        node = my_strlen(cmd_line) ? \
        create_leaf(NULL, my_str_to_word_array(cmd_line, " \t")) : NULL;
    return (node);
}
