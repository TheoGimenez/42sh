/*
** EPITECH PROJECT, 2019
** pipe_manag.c
** File description:
** manage pipe;
*/

#include "ftsh.h"

void pipe_fork(shell_t *shell, tree_t *tree)
{
    int sig = -1;
    int pid = fork();

    if (pid == -1)
        return (set_err(shell, 2));
    if (pid) {
        if (tree->right->parce)
            browse_binary_tree(shell, tree->right);
        else
            cmd_manager(shell, tree->right);
        waitpid(pid, &sig, 0);
        if (sig_catch(sig) || sig)
            return (set_err(shell, -1));
    } else {
        if (tree->left->parce)
            browse_binary_tree(shell, tree->left);
        else
            cmd_manager(shell, tree->left);
        exit(shell->error ? 512 : 0);
    }
}

void pipe_manager(shell_t *shell, tree_t *tree)
{
    int p_fd[2] = {0, 0};

    if (!tree->right || !tree->left)
        return (set_err(shell, 1));
    if (pipe(p_fd) == -1)
        return (set_err(shell, 2));
    memcpy(tree->right->fd, \
    (int []) {p_fd[0], tree->fd[1], tree->fd[0], p_fd[1]}, sizeof(int) * 4);
    memcpy(tree->left->fd, \
    (int []) {tree->fd[0], p_fd[1], p_fd[0], tree->fd[1]}, sizeof(int) * 4);
    pipe_fork(shell, tree);
}
