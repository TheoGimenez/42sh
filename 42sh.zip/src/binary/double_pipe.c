/*
** EPITECH PROJECT, 2019
** double_pipe.c
** File description:
** manage double pipe
*/

#include "ftsh.h"

void double_pipe(shell_t *shell, tree_t *tree)
{
    if (!tree->left || !tree->right || !tree->right->cmd)
        return (set_err(shell, 1));
    browse_binary_tree(shell, tree->left);
    if (shell->error == -1) {
        shell->error = 0;
        browse_binary_tree(shell, tree->right);
    }
}
