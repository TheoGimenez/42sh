/*
** EPITECH PROJECT, 2019
** glob.c
** File description:
** glob
*/

#include "ftsh.h"

char *my_str_cat_space(char *str, char *str2)
{
    int a = 0;

    for (; str[a]; a += 1);
    str[a] = ' ';
    a++;
    for (int b = 0; str2[b]; b += 1, a += 1)
        str[a] = str2[b];
    return (str);
}

int check_glob(shell_t *shell)
{
    for (int a = 0; shell->command_line[a]; a += 1)
        if (shell->command_line[a] == '*' || shell->command_line[a] == '?' || \
        shell->command_line[a] == '[' || shell->command_line[a] == ']')
            return (1);
    return (0);
}

void replace_glob(shell_t *shell)
{
    wordexp_t w;

    if (check_glob(shell)) {
        wordexp(shell->command_line, &w, WRDE_NOCMD);
        shell->command_line = calloc(CMD_SIZE, 1);
        shell->command_line = strcpy(shell->command_line, w.we_wordv[0]);
        for (int a = 1; (unsigned)a < w.we_wordc; a += 1)
            shell->command_line = my_str_cat_space(shell->command_line, \
            w.we_wordv[a]);
        wordfree(&w);
    }
}