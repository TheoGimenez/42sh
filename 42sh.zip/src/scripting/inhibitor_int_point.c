/*
** EPITECH PROJECT, 2018
** inhibitor_int_point.c
** File description:
** inhibitor int point
*/

#include "ftsh.h"
