/*
** EPITECH PROJECT, 2018
** init_struct.c
** File description:
** init shell struct
*/

#include "ftsh.h"

void display_pront(UNUSED int sig)
{
    if (isatty(0) == 1)
        write(1, "\n$> ", 4);
}

void my_crash(UNUSED int sig)
{
    exit(0);
}

void init_shell(shell_t *shell, char **env)
{
    signal(SIGSEGV, my_crash);
    signal(SIGABRT, my_crash);
    signal(SIGINT, display_pront);
    memset(shell, 0, sizeof(shell_t));
    shell->env = (!env || !*env) ? emergency_env() : env;
    shell->env_list = create_list_env(shell->env);
    shell->home = get_data_env(shell->env_list, "HOME");
    if (!get_data_env(shell->env_list, "PATH"))
        set_list_env(shell, "PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin" \
        ":/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin");
    strcpy(shell->path, get_data_env(shell->env_list, "PATH"));
    update_env(shell);
    shell->vector = calloc(1, sizeof(vector_t));
    create_vec(shell->vector);
    shell->command_history = calloc(1, sizeof(char *));
}
