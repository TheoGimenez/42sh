/*
** EPITECH PROJECT, 2018
** utile.h
** File description:
** my personal .h file
*/

#ifndef UTILE_H_
#define UTILE_H_

#define UNUSED __attribute__((unused))
#define CONST __attribute__((const))
#define VOID __attribute__((noreturn))

#define CMD_SIZE (1024 * 4)

#endif
