/*
** EPITECH PROJECT, 2018
** destroy.h
** File description:
** header file for destroy
*/

#ifndef _DESTROY_H_
#define _DESTROY_H_

void destroy_struct(shell_t *shell);

#endif
