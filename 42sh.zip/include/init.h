/*
** EPITECH PROJECT, 2018
** init.h
** File description:
** header file for init
*/

#ifndef _INIT_H_
#define _INIT_H_

void init_shell(shell_t *shell, char **env);

#endif
